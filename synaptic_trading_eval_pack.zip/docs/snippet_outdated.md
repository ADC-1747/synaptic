# (INTENTIONAL TRAP) Outdated Snippet

The following import path is **outdated/incorrect** in current Nautilus Trader versions. Detect and fix it.

```python
from nautilus_trader.backtest import BacktestEngine  # ❌ outdated
```
